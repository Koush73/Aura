# AuraFit project

## Folder layout
- `frontend/index.html` — page structure
- `frontend/style.css` — all original page styles
- `frontend/script.js` — all original browser-side application logic
- `backend/main.py` — FastAPI API starter with SQLite profile/progress storage and photo upload

## Run the frontend
Open `frontend/index.html` in a browser, or serve the `frontend` folder with VS Code Live Server (recommended).

## Run the backend (Windows)
Open a terminal in `aurafit/backend` and run:

```powershell
py -m venv .venv
.venv\Scripts\activate
py -m pip install -r requirements.txt
uvicorn main:app --reload
```

API docs: http://127.0.0.1:8000/docs
Health check: http://127.0.0.1:8000/api/health

## Important integration note
The supplied AuraFit page is currently a client-side application and uses browser `localStorage` for its account/profile/progress state. The new FastAPI backend is a separate working API foundation; the existing frontend JavaScript has not yet been changed to call these API routes. Do not assume that browser data is already being saved to SQLite. Authentication and authorization also need to be implemented before using this API with real users.
