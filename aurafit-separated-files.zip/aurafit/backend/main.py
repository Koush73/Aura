"""AuraFit API starter backend.

Run from the backend directory:
    python -m pip install -r requirements.txt
    uvicorn main:app --reload

The existing frontend currently stores its account/profile/progress data in
browser localStorage. These API endpoints are provided as a separate backend
foundation; the frontend has not yet been migrated to call them.
"""
from __future__ import annotations

import os
import sqlite3
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
UPLOAD_DIR = DATA_DIR / "uploads"
DB_PATH = DATA_DIR / "aurafit.db"
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)

app = FastAPI(title="AuraFit API", version="1.0.0", description="Profile, progress log and photo storage API for AuraFit.")

# Restrict this list to your deployed frontend origin before production.
allowed_origins = os.getenv("AURAFIT_CORS_ORIGINS", "http://127.0.0.1:5500,http://localhost:5500,http://127.0.0.1:8000,http://localhost:8000").split(",")
app.add_middleware(
    CORSMiddleware,
    allow_origins=[origin.strip() for origin in allowed_origins if origin.strip()],
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "DELETE"],
    allow_headers=["Content-Type"],
)


def db() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db() -> None:
    with db() as conn:
        conn.execute("""CREATE TABLE IF NOT EXISTS profiles (
            user_id TEXT PRIMARY KEY,
            display_name TEXT NOT NULL DEFAULT '',
            age INTEGER,
            height_cm REAL,
            weight_kg REAL,
            goal TEXT NOT NULL DEFAULT '',
            updated_at TEXT NOT NULL
        )""")
        conn.execute("""CREATE TABLE IF NOT EXISTS progress_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id TEXT NOT NULL,
            log_date TEXT NOT NULL,
            weight_kg REAL,
            notes TEXT NOT NULL DEFAULT '',
            photo_path TEXT,
            created_at TEXT NOT NULL
        )""")


@app.on_event("startup")
def startup() -> None:
    init_db()


class ProfileIn(BaseModel):
    display_name: str = Field(default="", max_length=100)
    age: int | None = Field(default=None, ge=13, le=120)
    height_cm: float | None = Field(default=None, gt=0, le=300)
    weight_kg: float | None = Field(default=None, gt=0, le=500)
    goal: str = Field(default="", max_length=500)


class ProgressIn(BaseModel):
    log_date: str
    weight_kg: float | None = Field(default=None, gt=0, le=500)
    notes: str = Field(default="", max_length=2000)
    photo_path: str | None = None


@app.get("/api/health")
def health() -> dict[str, str]:
    return {"status": "ok", "service": "AuraFit API"}


@app.get("/api/profiles/{user_id}")
def get_profile(user_id: str) -> dict[str, Any]:
    with db() as conn:
        row = conn.execute("SELECT * FROM profiles WHERE user_id = ?", (user_id,)).fetchone()
    if row is None:
        raise HTTPException(status_code=404, detail="Profile not found")
    return dict(row)


@app.put("/api/profiles/{user_id}")
def save_profile(user_id: str, payload: ProfileIn) -> dict[str, Any]:
    now = datetime.now(timezone.utc).isoformat()
    values = (payload.display_name, payload.age, payload.height_cm, payload.weight_kg, payload.goal, now, user_id)
    with db() as conn:
        conn.execute("""INSERT INTO profiles (display_name, age, height_cm, weight_kg, goal, updated_at, user_id)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(user_id) DO UPDATE SET display_name=excluded.display_name, age=excluded.age,
            height_cm=excluded.height_cm, weight_kg=excluded.weight_kg, goal=excluded.goal, updated_at=excluded.updated_at""", values)
        row = conn.execute("SELECT * FROM profiles WHERE user_id = ?", (user_id,)).fetchone()
    return dict(row)


@app.post("/api/progress/{user_id}", status_code=201)
def add_progress(user_id: str, payload: ProgressIn) -> dict[str, Any]:
    now = datetime.now(timezone.utc).isoformat()
    with db() as conn:
        cur = conn.execute("INSERT INTO progress_logs (user_id, log_date, weight_kg, notes, photo_path, created_at) VALUES (?, ?, ?, ?, ?, ?)",
                           (user_id, payload.log_date, payload.weight_kg, payload.notes, payload.photo_path, now))
        row = conn.execute("SELECT * FROM progress_logs WHERE id = ?", (cur.lastrowid,)).fetchone()
    return dict(row)


@app.get("/api/progress/{user_id}")
def list_progress(user_id: str) -> list[dict[str, Any]]:
    with db() as conn:
        rows = conn.execute("SELECT * FROM progress_logs WHERE user_id = ? ORDER BY log_date DESC, id DESC", (user_id,)).fetchall()
    return [dict(row) for row in rows]


@app.delete("/api/progress/{user_id}/{entry_id}")
def delete_progress(user_id: str, entry_id: int) -> dict[str, str]:
    with db() as conn:
        cur = conn.execute("DELETE FROM progress_logs WHERE id = ? AND user_id = ?", (entry_id, user_id))
    if cur.rowcount == 0:
        raise HTTPException(status_code=404, detail="Progress entry not found")
    return {"message": "Progress entry deleted"}


@app.post("/api/photos/{user_id}", status_code=201)
async def upload_progress_photo(user_id: str, photo: UploadFile = File(...)) -> dict[str, str]:
    allowed = {"image/jpeg": ".jpg", "image/png": ".png", "image/webp": ".webp"}
    if photo.content_type not in allowed:
        raise HTTPException(status_code=415, detail="Only JPEG, PNG and WEBP images are supported")
    content = await photo.read(8 * 1024 * 1024 + 1)
    if len(content) > 8 * 1024 * 1024:
        raise HTTPException(status_code=413, detail="Photo must be 8 MB or smaller")
    filename = f"{uuid.uuid4().hex}{allowed[photo.content_type]}"
    destination = UPLOAD_DIR / filename
    destination.write_bytes(content)
    return {"photo_path": f"/uploads/{filename}", "filename": filename}
