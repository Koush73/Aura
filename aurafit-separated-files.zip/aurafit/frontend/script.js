/* ============================================================
   AuraFit AI — Complete Application Logic
   ============================================================ */

// ===== STATE =====
const APP_STATE = {
  currentUser: null,
  profile: null,
  progressLogs: [],
  pendingProgressPhoto: null,
  currentTheme: 'light'
};

// ===== DATABASE SIMULATION =====
const DB = {
  users: [],
  user_profiles: [],
  physique_scans: [
    { id: 'e5f6a7b8-c9d0-1234-efab-345678901234', user_id: 'a1b2c3d4-e5f6-7890-abcd-ef1234567890', current_img_url: '/scans/alex_current.jpg', target_img_url: '/scans/alex_target.jpg', current_bf_pct: 19.2, target_bf_pct: 11.3, v_taper_ratio: 1.42, morphological_delta: '{"shoulders":+0.23,"chest":+0.18}', scanned_at: '2026-10-28 10:20:00' }
  ],
  progress_logs: []
};

// ===== THEME MANAGEMENT =====
function initTheme() {
  const saved = localStorage.getItem('aurafit_theme');
  if (saved) {
    APP_STATE.currentTheme = saved;
    document.documentElement.setAttribute('data-theme', saved);
  }
  updateThemeButton();
}

function toggleTheme() {
  APP_STATE.currentTheme = APP_STATE.currentTheme === 'light' ? 'dark' : 'light';
  document.documentElement.setAttribute('data-theme', APP_STATE.currentTheme);
  localStorage.setItem('aurafit_theme', APP_STATE.currentTheme);
  updateThemeButton();
}

function updateThemeButton() {
  const btn = document.getElementById('themeToggleBtn');
  btn.textContent = APP_STATE.currentTheme === 'light' ? '🌙 Dark Mode' : '☀️ Light Mode';
}

// ===== AUTH MANAGEMENT (BROWSER-ONLY PROTOTYPE) =====
function getStoredAccounts() {
  try { return JSON.parse(localStorage.getItem('aurafit_accounts') || '[]'); }
  catch (_) { return []; }
}

async function hashPassword(password) {
  const bytes = new TextEncoder().encode(password);
  const digest = await crypto.subtle.digest('SHA-256', bytes);
  return Array.from(new Uint8Array(digest)).map(b => b.toString(16).padStart(2, '0')).join('');
}

function initAuth() {
  const savedUser = localStorage.getItem('aurafit_user');
  if (savedUser) {
    try {
      APP_STATE.currentUser = JSON.parse(savedUser);
      document.body.classList.remove('auth-required');
      renderAuthState();
      APP_STATE.profile = loadSavedProfile();
      setDashboardAccess(Boolean(APP_STATE.profile));
      switchTab('profile', true);
      return;
    } catch (_) {
      localStorage.removeItem('aurafit_user');
      localStorage.removeItem('aurafit_token');
    }
  }
  document.body.classList.add('auth-required');
  openAuthModal();
  switchAuthTab('register');
}

function openAuthModal() {
  document.getElementById('authModal').classList.add('active');
}

function closeAuthModal() {
  if (!APP_STATE.currentUser) return;
  document.getElementById('authModal').classList.remove('active');
}

function switchAuthTab(tab) {
  document.querySelectorAll('.modal-tab-btn').forEach(b => b.classList.remove('active'));
  document.querySelectorAll('.modal-tab-content').forEach(c => c.classList.remove('active'));
  document.getElementById(tab === 'signin' ? 'authTabSignin' : 'authTabRegister').classList.add('active');
  document.getElementById(tab === 'signin' ? 'signinContent' : 'registerContent').classList.add('active');
}

async function handleSignIn(e) {
  e.preventDefault();
  const email = document.getElementById('signinEmail').value.trim().toLowerCase();
  const password = document.getElementById('signinPassword').value;
  const account = getStoredAccounts().find(a => a.email === email);
  if (!account || account.passwordHash !== await hashPassword(password)) {
    alert('Invalid email or password. Register first if you do not have an account on this browser.');
    return;
  }
  loginUser({ id: account.id, email: account.email, full_name: account.full_name, is_active: true });
}

async function handleRegister(e) {
  e.preventDefault();
  const name = document.getElementById('regName').value.trim();
  const email = document.getElementById('regEmail').value.trim().toLowerCase();
  const password = document.getElementById('regPassword').value;
  if (password.length < 8) {
    alert('Use a password with at least 8 characters.');
    return;
  }
  const accounts = getStoredAccounts();
  if (accounts.some(a => a.email === email)) {
    alert('An account with this email already exists. Please sign in.');
    switchAuthTab('signin');
    return;
  }
  const account = {
    id: (crypto.randomUUID ? crypto.randomUUID() : 'user-' + Date.now()),
    email, full_name: name, passwordHash: await hashPassword(password),
    created_at: new Date().toISOString()
  };
  accounts.push(account);
  localStorage.setItem('aurafit_accounts', JSON.stringify(accounts));
  loginUser({ id: account.id, email, full_name: name, is_active: true });
}

function loginUser(user) {
  APP_STATE.currentUser = user;
  localStorage.setItem('aurafit_token', btoa(JSON.stringify({ sub: user.email, exp: Date.now() + 86400000 })));
  localStorage.setItem('aurafit_user', JSON.stringify(user));
  document.body.classList.remove('auth-required');
  document.getElementById('authModal').classList.remove('active');
  renderAuthState();
  APP_STATE.profile = loadSavedProfile();
  setDashboardAccess(Boolean(APP_STATE.profile));
  switchTab('profile', true);
}

function signOut() {
  APP_STATE.currentUser = null;
  APP_STATE.profile = null;
  setDashboardAccess(false);
  localStorage.removeItem('aurafit_token');
  localStorage.removeItem('aurafit_user');
  document.body.classList.add('auth-required');
  renderAuthState();
  switchAuthTab('signin');
  openAuthModal();
}

function renderAuthState() {
  const section = document.getElementById('authSection');
  if (APP_STATE.currentUser) {
    const u = APP_STATE.currentUser;
    const initials = (u.full_name || u.email).split(' ').map(w => w[0]).join('').substring(0, 2);
    section.innerHTML = `<div class="user-badge"><div class="user-avatar">${initials}</div><div class="user-info"><span class="user-name">${u.full_name || u.email}</span><span class="user-status">● Active</span></div></div><button class="btn btn-sm btn-ghost" onclick="signOut()">Sign Out</button>`;
  } else {
    section.innerHTML = `<button id="authSignInBtn" class="btn btn-primary btn-sm" onclick="openAuthModal()">Sign In / Register</button>`;
  }
}

// ===== DASHBOARD SEQUENCE / ACCESS CONTROL =====
const DASHBOARD_TABS = ['vision', 'workout', 'nutrition', 'progress'];
let dashboardTemplates = {};
let dashboardsUnlocked = false;

function profileStorageKey() {
  return APP_STATE.currentUser ? `aurafit_profile_${APP_STATE.currentUser.id}` : null;
}

function captureAndEmptyDashboards() {
  DASHBOARD_TABS.forEach(id => {
    const panelId = ({ vision: 'panelVision', workout: 'panelWorkout', nutrition: 'panelNutrition', progress: 'panelProgress' })[id];
    const panel = document.getElementById(panelId);
    if (panel && !dashboardTemplates[id]) dashboardTemplates[id] = panel.innerHTML;
    if (panel) panel.innerHTML = '';
  });
}

function setDashboardAccess(unlocked) {
  dashboardsUnlocked = Boolean(unlocked && APP_STATE.currentUser && APP_STATE.profile);
  DASHBOARD_TABS.forEach(id => {
    const tabId = ({ vision: 'tabVision', workout: 'tabWorkout', nutrition: 'tabNutrition', progress: 'tabProgress' })[id];
    const button = document.getElementById(tabId);
    if (button) {
      button.disabled = !dashboardsUnlocked;
      button.setAttribute('aria-disabled', String(!dashboardsUnlocked));
      button.title = dashboardsUnlocked ? '' : 'Complete Profile & Bio to unlock this dashboard';
    }
  });

  if (dashboardsUnlocked) {
    DASHBOARD_TABS.forEach(id => {
      const panelId = ({ vision: 'panelVision', workout: 'panelWorkout', nutrition: 'panelNutrition', progress: 'panelProgress' })[id];
      const panel = document.getElementById(panelId);
      if (panel && !panel.innerHTML.trim()) panel.innerHTML = dashboardTemplates[id] || '';
    });
    updateNutritionCalcs(APP_STATE.profile);
    generateWorkout();
    generateMealPlan();
    clearProgressFormForNewUser();
    loadProgressLogsForCurrentUser();
    renderProgressChart();
    renderProgressPhotoHistory();
  } else {
    captureAndEmptyDashboards();
    switchTab('profile', true);
  }
}

function clearProgressFormForNewUser() {
  ['progWeight', 'progWaist', 'progChest', 'progArm'].forEach(id => {
    const field = document.getElementById(id);
    if (field) field.value = '';
  });
  const adherence = document.getElementById('progAdherence');
  if (adherence) adherence.value = '';
  const chart = document.getElementById('progressChart');
  if (chart) chart.innerHTML = '';
  const feedback = document.getElementById('adaptiveFeedback');
  if (feedback) feedback.innerHTML = '';
  removeProgressPhoto();
}

function loadSavedProfile() {
  const key = profileStorageKey();
  if (!key) return null;
  try { return JSON.parse(localStorage.getItem(key) || 'null'); }
  catch (_) { return null; }
}

function switchTab(tabId, force = false) {
  if (!force && tabId !== 'profile' && !dashboardsUnlocked) {
    alert('Complete and save your Profile & Bio first. The other dashboards will unlock afterwards.');
    return;
  }
  document.querySelectorAll('.tab-btn, .header-profile-btn').forEach(b => {
    b.classList.remove('active');
    b.setAttribute('aria-selected', 'false');
  });
  document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
  const tabMap = { profile: 'tabProfile', vision: 'tabVision', workout: 'tabWorkout', nutrition: 'tabNutrition', progress: 'tabProgress' };
  const panelMap = { profile: 'panelProfile', vision: 'panelVision', workout: 'panelWorkout', nutrition: 'panelNutrition', progress: 'panelProgress' };
  if (!tabMap[tabId] || !panelMap[tabId]) return;
  document.getElementById(tabMap[tabId]).classList.add('active');
  document.getElementById(tabMap[tabId]).setAttribute('aria-selected', 'true');
  document.getElementById(panelMap[tabId]).classList.add('active');

  if (tabId === 'workout' && dashboardsUnlocked) generateWorkout();
  if (tabId === 'nutrition' && dashboardsUnlocked) generateMealPlan();
  if (tabId === 'progress' && dashboardsUnlocked) renderProgressChart();
}

function saveProfile(e) {
  e.preventDefault();
  if (!APP_STATE.currentUser) { openAuthModal(); return; }
  const form = document.getElementById('profileForm');
  if (!form.reportValidity()) return;

  const profile = {
    age: Number(document.getElementById('profileAge').value),
    sex: document.getElementById('profileSex').value,
    height: Number(document.getElementById('profileHeight').value),
    weight: Number(document.getElementById('profileWeight').value),
    experience: document.getElementById('profileExperience').value,
    goal: document.getElementById('profileGoal').value,
    duration: Number(document.getElementById('profileDuration').value),
    days: Number(document.getElementById('profileDays').value),
    equipment: document.getElementById('profileEquipment').value,
    diet: document.getElementById('profileDiet').value
  };

  if (!profile.age || !profile.height || !profile.weight || Object.values(profile).some(v => v === '' || v === null || Number.isNaN(v))) {
    alert('Please complete every field in Profile & Bio before continuing.');
    return;
  }

  APP_STATE.profile = profile;
  const key = profileStorageKey();
  if (key) localStorage.setItem(key, JSON.stringify(profile));

  const userId = APP_STATE.currentUser.id;
  const existing = DB.user_profiles.find(p => p.user_id === userId);
  const dbProfile = {
    id: existing ? existing.id : (crypto.randomUUID ? crypto.randomUUID() : 'prof-' + Date.now()),
    user_id: userId,
    age: profile.age, gender: profile.sex,
    height_cm: profile.height, weight_kg: profile.weight,
    training_experience: profile.experience,
    fitness_goal: profile.goal,
    duration_mins: profile.duration, days_per_week: profile.days,
    equipment: profile.equipment, dietary_preference: profile.diet,
    updated_at: new Date().toISOString().replace('T', ' ').substring(0, 19)
  };
  if (existing) Object.assign(existing, dbProfile);
  else DB.user_profiles.push(dbProfile);

  setDashboardAccess(true);
  const btn = form.querySelector('button[type="submit"]');
  if (btn) {
    const original = btn.innerHTML;
    btn.innerHTML = '✅ Profile Completed — Dashboards Unlocked';
    btn.style.background = 'var(--accent-emerald)';
    setTimeout(() => { btn.innerHTML = original; btn.style.background = ''; }, 2500);
  }
  alert('Profile completed! CV Physique Lab, AI Workout, AI Nutrition and Progress dashboards are now unlocked.');
}

function updateNutritionCalcs(p) {
  if (!p) return;
  let bmr;
  if (p.sex === 'male') bmr = 10 * p.weight + 6.25 * p.height - 5 * p.age + 5;
  else bmr = 10 * p.weight + 6.25 * p.height - 5 * p.age - 161;
  const activityMultiplier = p.days <= 3 ? 1.55 : p.days <= 4 ? 1.65 : p.days <= 5 ? 1.75 : 1.85;
  let tdee = Math.round(bmr * activityMultiplier);
  if (p.goal === 'fat_loss') tdee -= 350;
  else if (p.goal === 'hypertrophy') tdee += 300;
  else if (p.goal === 'recomposition') tdee -= 100;

  const protein = Math.round(p.weight * 2.2);
  const proteinCals = protein * 4;
  const fatCals = Math.round(tdee * 0.25);
  const fat = Math.round(fatCals / 9);
  const carbCals = tdee - proteinCals - fatCals;
  const carbs = Math.round(carbCals / 4);

  document.getElementById('tdeeValue').textContent = tdee.toLocaleString();
  document.getElementById('proteinValue').textContent = protein + 'g';
  document.getElementById('carbsFatValue').textContent = carbs + 'g / ' + fat + 'g';
}

// ===== PHYSIQUE PHOTO UPLOAD & PREVIEW =====
const physiquePhotoUrls = { current: null, target: null };

function openPhysiquePicker(type) {
  const input = document.getElementById(type + 'PhotoInput');
  if (input) input.click();
}

function handlePhysiqueDragOver(event) {
  event.preventDefault();
  event.currentTarget.classList.add('is-dragover');
}

function handlePhysiqueDragLeave(event) {
  event.currentTarget.classList.remove('is-dragover');
}

function handlePhysiqueDrop(event, type) {
  event.preventDefault();
  event.currentTarget.classList.remove('is-dragover');
  const files = event.dataTransfer && event.dataTransfer.files;
  if (!files || !files.length) return;
  const input = document.getElementById(type + 'PhotoInput');
  input.files = files;
  previewPhysiquePhoto(type, input);
}

function previewPhysiquePhoto(type, input) {
  const file = input.files && input.files[0];
  if (!file) return;
  const allowed = ['image/jpeg', 'image/png', 'image/webp'];
  if (!allowed.includes(file.type)) {
    alert('Please select a JPG, PNG, or WebP image.');
    input.value = '';
    return;
  }
  if (file.size > 10 * 1024 * 1024) {
    alert('Image must be 10 MB or smaller.');
    input.value = '';
    return;
  }
  if (physiquePhotoUrls[type]) URL.revokeObjectURL(physiquePhotoUrls[type]);
  const url = URL.createObjectURL(file);
  physiquePhotoUrls[type] = url;
  const preview = document.getElementById(type + 'PhotoPreview');
  preview.src = url;
  preview.hidden = false;
  document.getElementById(type + 'PhysiqueContainer').classList.add('has-photo');
  document.getElementById('analysisResults').classList.add('hidden');
}

function runPhysiqueAnalysis() {
  if (!physiquePhotoUrls.current || !physiquePhotoUrls.target) {
    alert('Upload both your current physique photo and target reference photo before running the comparison.');
    return;
  }
  const sl1 = document.getElementById('scanLine1');
  const sl2 = document.getElementById('scanLine2');
  sl1.classList.add('active');
  sl2.classList.add('active');
  setTimeout(() => {
    sl1.classList.remove('active');
    sl2.classList.remove('active');
    document.getElementById('analysisResults').classList.remove('hidden');
    drawRadarChart();
  }, 1200);
}

// ===== HUMAN-FRIENDLY GROUPED BAR GRAPH (Replaces Radar Chart) =====
function drawRadarChart() {
  const svg = document.getElementById('radarChart');
  if (!svg) return;

  const labels = ['Shoulders', 'Chest', 'Arms', 'Legs', 'Back'];
  const current = [65, 60, 58, 70, 55]; // Current percentages
  const target = [90, 85, 80, 82, 88];  // Target percentages

  const width = 620, height = 300;
  const pad = { top: 40, right: 25, bottom: 45, left: 50 };
  const chartW = width - pad.left - pad.right;
  const chartH = height - pad.top - pad.bottom;

  let html = `
    <defs>
      <linearGradient id="currBarGrad" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0%" stop-color="#22d3ee"/>
        <stop offset="100%" stop-color="#06b6d4"/>
      </linearGradient>
      <linearGradient id="targBarGrad" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0%" stop-color="#a78bfa"/>
        <stop offset="100%" stop-color="#8b5cf6"/>
      </linearGradient>
    </defs>
  `;

  // Horizontal Y-axis grid lines (0% to 100%)
  [0, 25, 50, 75, 100].forEach(val => {
    const y = pad.top + chartH - (val / 100) * chartH;
    html += `<line x1="${pad.left}" y1="${y}" x2="${width - pad.right}" y2="${y}" stroke="var(--border-subtle)" stroke-width="1" stroke-dasharray="${val === 0 ? 'none' : '4 4'}" opacity="0.6"/>`;
    html += `<text x="${pad.left - 10}" y="${y + 4}" text-anchor="end" fill="var(--text-muted)" font-size="11" font-weight="600" font-family="var(--font-sans)">${val}%</text>`;
  });

  // Bars for each muscle group
  const groupW = chartW / labels.length;
  const barW = 28;
  const gap = 8;

  labels.forEach((label, i) => {
    const groupCenter = pad.left + groupW * i + groupW / 2;
    const curVal = current[i];
    const tarVal = target[i];
    const diff = tarVal - curVal;

    const curH = (curVal / 100) * chartH;
    const tarH = (tarVal / 100) * chartH;

    const curX = groupCenter - barW - gap / 2;
    const tarX = groupCenter + gap / 2;

    const curY = pad.top + chartH - curH;
    const tarY = pad.top + chartH - tarH;

    // Current Bar (Cyan)
    html += `<rect x="${curX}" y="${curY}" width="${barW}" height="${curH}" rx="5" fill="url(#currBarGrad)"/>`;
    html += `<text x="${curX + barW / 2}" y="${curY - 6}" text-anchor="middle" fill="#06b6d4" font-size="11" font-weight="700" font-family="var(--font-sans)">${curVal}%</text>`;

    // Target Bar (Violet)
    html += `<rect x="${tarX}" y="${tarY}" width="${barW}" height="${tarH}" rx="5" fill="url(#targBarGrad)"/>`;
    html += `<text x="${tarX + barW / 2}" y="${tarY - 6}" text-anchor="middle" fill="#8b5cf6" font-size="11" font-weight="700" font-family="var(--font-sans)">${tarVal}%</text>`;

    // Growth Needed Pill Badge above the pair
    const badgeY = Math.min(curY, tarY) - 28;
    html += `<rect x="${groupCenter - 22}" y="${badgeY - 11}" width="44" height="16" rx="8" fill="rgba(16,185,129,0.15)"/>`;
    html += `<text x="${groupCenter}" y="${badgeY}" text-anchor="middle" fill="var(--accent-emerald)" font-size="10" font-weight="800" font-family="var(--font-sans)">+${diff}%</text>`;

    // Muscle Group Name on X-Axis
    html += `<text x="${groupCenter}" y="${height - 14}" text-anchor="middle" fill="var(--text-main)" font-size="12" font-weight="700" font-family="var(--font-sans)">${label}</text>`;
  });

  svg.innerHTML = html;
}

// ===== WORKOUT GENERATION =====
function generateWorkout() {
  const p = APP_STATE.profile || { days: 4, equipment: 'full_gym', duration: 60, goal: 'recomposition' };
  const container = document.getElementById('workoutContent');

  const workouts = {
    full_gym: [
      { day: 'Day 1 — Upper Body (Push Focus)', exercises: [
        { name: 'Incline Barbell Press', muscle: 'Upper Chest', sets: '4 × 8', tempo: '3-0-1-0 / 90s', cue: 'CV cue: Maintain 45° shoulder angle; scapulae retracted' },
        { name: 'Seated Dumbbell OHP', muscle: 'Anterior Delts', sets: '3 × 10', tempo: '2-1-1-0 / 75s', cue: 'CV cue: Elbows track at 30° forward of midline' },
        { name: 'Cable Lateral Raise', muscle: 'Lateral Delts', sets: '4 × 15', tempo: '2-1-2-0 / 60s', cue: 'CV cue: Arm elevation to 80°; no trap shrug detected' },
        { name: 'Triceps Rope Pushdown', muscle: 'Triceps', sets: '3 × 12', tempo: '2-0-1-1 / 60s', cue: 'CV cue: Elbow fixed at ribcage; full extension' },
        { name: 'Pec Deck Flye', muscle: 'Chest (stretch)', sets: '3 × 12', tempo: '2-2-1-0 / 60s', cue: 'CV cue: Peak contraction hold 2s; ROM ≥ 140°' }
      ]},
      { day: 'Day 2 — Lower Body (Quad Focus)', exercises: [
        { name: 'Barbell Back Squat', muscle: 'Quadriceps', sets: '4 × 6', tempo: '3-1-1-0 / 120s', cue: 'CV cue: Hip crease below knee; knee track over toes' },
        { name: 'Leg Press (High & Wide)', muscle: 'Glutes / Quads', sets: '3 × 10', tempo: '3-0-1-0 / 90s', cue: 'CV cue: Full ROM; no lumbar flexion at bottom' },
        { name: 'Walking Lunges', muscle: 'Quads / Glutes', sets: '3 × 12/leg', tempo: '2-0-1-0 / 60s', cue: 'CV cue: Front knee ≤ 5° valgus; upright torso' },
        { name: 'Leg Extension', muscle: 'Quadriceps', sets: '3 × 15', tempo: '2-1-1-0 / 60s', cue: 'CV cue: Peak contraction 1s; controlled eccentric' },
        { name: 'Standing Calf Raise', muscle: 'Calves', sets: '4 × 15', tempo: '1-2-1-0 / 45s', cue: 'CV cue: Full dorsiflexion stretch each rep' }
      ]},
      { day: 'Day 3 — Upper Body (Pull Focus)', exercises: [
        { name: 'Weighted Pull-Ups', muscle: 'Lats', sets: '4 × 8', tempo: '2-1-1-0 / 90s', cue: 'CV cue: Full dead hang start; chin clears bar' },
        { name: 'Chest-Supported Row', muscle: 'Mid Back', sets: '4 × 10', tempo: '2-1-1-1 / 75s', cue: 'CV cue: Scapulae full retraction; no momentum' },
        { name: 'Face Pulls', muscle: 'Rear Delts', sets: '4 × 15', tempo: '1-2-1-0 / 60s', cue: 'CV cue: External rotation at peak; elbows above shoulders' },
        { name: 'Barbell Curl', muscle: 'Biceps', sets: '3 × 10', tempo: '2-1-1-0 / 60s', cue: 'CV cue: No elbow drift; supinated grip throughout' },
        { name: 'Hammer Curl', muscle: 'Brachialis', sets: '3 × 12', tempo: '2-0-1-0 / 60s', cue: 'CV cue: Neutral wrist; controlled negative' }
      ]},
      { day: 'Day 4 — Lower Body (Posterior Chain)', exercises: [
        { name: 'Romanian Deadlift', muscle: 'Hamstrings', sets: '4 × 8', tempo: '3-1-1-0 / 90s', cue: 'CV cue: Hip hinge > 80°; bar path vertical' },
        { name: 'Bulgarian Split Squat', muscle: 'Glutes / Quads', sets: '3 × 10/leg', tempo: '2-1-1-0 / 75s', cue: 'CV cue: Rear knee 2" from floor; torso upright' },
        { name: 'Leg Curl (Lying)', muscle: 'Hamstrings', sets: '3 × 12', tempo: '2-1-1-0 / 60s', cue: 'CV cue: Hips pinned; no lumbar extension' },
        { name: 'Hip Thrust', muscle: 'Glutes', sets: '3 × 12', tempo: '2-2-1-0 / 75s', cue: 'CV cue: Full hip extension; posterior pelvic tilt at top' },
        { name: 'Seated Calf Raise', muscle: 'Soleus', sets: '4 × 15', tempo: '1-2-1-0 / 45s', cue: 'CV cue: Slow eccentric; pause at stretch' }
      ]}
    ],
    home_db: [
      { day: 'Day 1 — Full Body Push', exercises: [
        { name: 'DB Floor Press', muscle: 'Chest', sets: '4 × 10', tempo: '2-1-1-0 / 75s', cue: 'CV cue: Elbows at 45°; full lockout' },
        { name: 'DB Arnold Press', muscle: 'Shoulders', sets: '3 × 10', tempo: '2-0-1-0 / 75s', cue: 'CV cue: Full rotation arc; controlled tempo' },
        { name: 'DB Lateral Raise', muscle: 'Lateral Delts', sets: '4 × 15', tempo: '2-1-2-0 / 60s', cue: 'CV cue: Lead with pinkies; no swinging' },
        { name: 'DB Goblet Squat', muscle: 'Quads', sets: '4 × 12', tempo: '3-0-1-0 / 75s', cue: 'CV cue: Elbows inside knees at bottom' },
        { name: 'DB Skull Crushers', muscle: 'Triceps', sets: '3 × 12', tempo: '2-0-1-0 / 60s', cue: 'CV cue: Elbows stationary; full stretch' }
      ]},
      { day: 'Day 2 — Full Body Pull', exercises: [
        { name: 'DB Bent-Over Row', muscle: 'Back', sets: '4 × 10', tempo: '2-1-1-0 / 75s', cue: 'CV cue: Torso at 45°; full scapular retraction' },
        { name: 'DB Romanian Deadlift', muscle: 'Hamstrings', sets: '4 × 10', tempo: '3-1-1-0 / 90s', cue: 'CV cue: Hip hinge pattern; soft knees' },
        { name: 'DB Rear Delt Flye', muscle: 'Rear Delts', sets: '3 × 15', tempo: '2-1-1-0 / 60s', cue: 'CV cue: Chest on bench; squeeze at peak' },
        { name: 'DB Curl', muscle: 'Biceps', sets: '3 × 12', tempo: '2-1-1-0 / 60s', cue: 'CV cue: Supinate at top; slow negative' },
        { name: 'DB Step-Up', muscle: 'Glutes / Quads', sets: '3 × 10/leg', tempo: '2-0-1-0 / 60s', cue: 'CV cue: Drive through heel; no push-off' }
      ]},
      { day: 'Day 3 — Full Body Hypertrophy', exercises: [
        { name: 'DB Incline Press', muscle: 'Upper Chest', sets: '4 × 10', tempo: '2-1-1-0 / 75s', cue: 'CV cue: Bench at 30°; full stretch at bottom' },
        { name: 'DB Sumo Squat', muscle: 'Adductors / Quads', sets: '3 × 12', tempo: '3-1-1-0 / 75s', cue: 'CV cue: Toes out 45°; knees track toes' },
        { name: 'Single-Arm DB Row', muscle: 'Lats', sets: '3 × 10/side', tempo: '2-1-1-0 / 60s', cue: 'CV cue: Full stretch to contraction; no rotation' },
        { name: 'DB Shoulder Press', muscle: 'Delts', sets: '3 × 10', tempo: '2-0-1-0 / 75s', cue: 'CV cue: Neutral path; no excessive arch' },
        { name: 'DB Lunge', muscle: 'Quads / Glutes', sets: '3 × 10/leg', tempo: '2-0-1-0 / 60s', cue: 'CV cue: Step length consistent; upright torso' }
      ]}
    ],
    bands: [
      { day: 'Day 1 — Band Upper Body', exercises: [
        { name: 'Band Push-Up', muscle: 'Chest', sets: '4 × 15', tempo: '2-0-1-0 / 60s', cue: 'CV cue: Band across upper back; full lockout' },
        { name: 'Band Pull-Apart', muscle: 'Rear Delts', sets: '4 × 20', tempo: '1-2-1-0 / 45s', cue: 'CV cue: Arms straight; squeeze at peak' },
        { name: 'Band Lateral Raise', muscle: 'Lateral Delts', sets: '3 × 15', tempo: '2-1-1-0 / 60s', cue: 'CV cue: Stand on band center; controlled arc' },
        { name: 'Band Bicep Curl', muscle: 'Biceps', sets: '3 × 15', tempo: '2-1-1-0 / 45s', cue: 'CV cue: Elbows pinned; full ROM' },
        { name: 'Band Tricep Extension', muscle: 'Triceps', sets: '3 × 15', tempo: '2-0-1-0 / 45s', cue: 'CV cue: Overhead anchor; full extension' }
      ]},
      { day: 'Day 2 — Band Lower Body', exercises: [
        { name: 'Band Squat', muscle: 'Quads', sets: '4 × 15', tempo: '3-0-1-0 / 60s', cue: 'CV cue: Band under feet; parallel depth' },
        { name: 'Band Good Morning', muscle: 'Hamstrings', sets: '3 × 12', tempo: '3-1-1-0 / 60s', cue: 'CV cue: Hip hinge focus; band at neck' },
        { name: 'Band Lateral Walk', muscle: 'Glute Med', sets: '3 × 15/side', tempo: 'Continuous / 45s', cue: 'CV cue: Quarter squat maintained; no valgus' },
        { name: 'Band Leg Curl', muscle: 'Hamstrings', sets: '3 × 15', tempo: '2-1-1-0 / 45s', cue: 'CV cue: Prone position; band at ankle' },
        { name: 'Band Calf Raise', muscle: 'Calves', sets: '3 × 20', tempo: '1-2-1-0 / 45s', cue: 'CV cue: Full ROM; peak squeeze' }
      ]}
    ],
    bodyweight: [
      { day: 'Day 1 — BW Upper Push', exercises: [
        { name: 'Push-Ups (varied width)', muscle: 'Chest', sets: '4 × 15', tempo: '2-1-1-0 / 60s', cue: 'CV cue: Full ROM; body straight line' },
        { name: 'Pike Push-Ups', muscle: 'Shoulders', sets: '3 × 10', tempo: '2-1-1-0 / 75s', cue: 'CV cue: Hips high; head toward floor' },
        { name: 'Diamond Push-Ups', muscle: 'Triceps', sets: '3 × 12', tempo: '2-0-1-0 / 60s', cue: 'CV cue: Hands together; elbows tight' },
        { name: 'Decline Push-Ups', muscle: 'Upper Chest', sets: '3 × 12', tempo: '2-0-1-0 / 60s', cue: 'CV cue: Feet elevated 12-18"' },
        { name: 'Plank', muscle: 'Core', sets: '3 × 45s', tempo: 'Isometric / 45s', cue: 'CV cue: Neutral spine; no hip sag' }
      ]},
      { day: 'Day 2 — BW Lower', exercises: [
        { name: 'Bodyweight Squat', muscle: 'Quads', sets: '4 × 20', tempo: '2-1-1-0 / 60s', cue: 'CV cue: Below parallel; weight on heels' },
        { name: 'Reverse Lunges', muscle: 'Glutes', sets: '3 × 12/leg', tempo: '2-0-1-0 / 60s', cue: 'CV cue: Step back; front knee stable' },
        { name: 'Glute Bridge', muscle: 'Glutes', sets: '4 × 15', tempo: '2-2-1-0 / 45s', cue: 'CV cue: Full hip extension; squeeze at top' },
        { name: 'Wall Sit', muscle: 'Quads', sets: '3 × 45s', tempo: 'Isometric / 60s', cue: 'CV cue: 90° knee angle; back flat on wall' },
        { name: 'Calf Raises', muscle: 'Calves', sets: '3 × 25', tempo: '1-2-1-0 / 45s', cue: 'CV cue: Single-leg for progression; full stretch' }
      ]},
      { day: 'Day 3 — BW Upper Pull & Core', exercises: [
        { name: 'Inverted Rows (table)', muscle: 'Back', sets: '4 × 10', tempo: '2-1-1-0 / 75s', cue: 'CV cue: Body straight; chest to edge' },
        { name: 'Superman Holds', muscle: 'Lower Back', sets: '3 × 12', tempo: '1-3-1-0 / 60s', cue: 'CV cue: Arms and legs elevated; squeeze' },
        { name: 'Towel Curl (isometric)', muscle: 'Biceps', sets: '3 × 10', tempo: '5s hold / 60s', cue: 'CV cue: Max tension each rep' },
        { name: 'Mountain Climbers', muscle: 'Core / Cardio', sets: '3 × 30s', tempo: 'Fast / 45s', cue: 'CV cue: Hips level; alternating drive' },
        { name: 'Dead Bug', muscle: 'Core', sets: '3 × 10/side', tempo: '3-0-3-0 / 60s', cue: 'CV cue: Lower back pressed to floor' }
      ]}
    ]
  };

  const equipment = p.equipment || 'full_gym';
  const plan = workouts[equipment] || workouts.full_gym;
  const daysToShow = plan.slice(0, p.days || 4);

  let html = '';
  daysToShow.forEach(day => {
    html += `<div class="workout-day-title">📅 ${day.day}</div>`;
    html += `<div class="table-container mb-16"><table>
      <thead><tr><th>Exercise</th><th>Target Muscle</th><th>Sets × Reps</th><th>Tempo / Rest</th><th>OpenCV Coaching Cue</th></tr></thead><tbody>`;
    day.exercises.forEach(ex => {
      html += `<tr><td style="font-weight:600">${ex.name}</td><td><span class="badge badge-cyan">${ex.muscle}</span></td><td>${ex.sets}</td><td style="font-family:var(--font-mono);font-size:0.78rem">${ex.tempo}</td><td style="font-size:0.78rem;color:var(--text-secondary)">${ex.cue}</td></tr>`;
    });
    html += `</tbody></table></div>`;
  });

  container.innerHTML = html;
}

// ===== NUTRITION MEAL PLAN =====
function generateMealPlan() {
  const p = APP_STATE.profile || { diet: 'high_protein', weight: 82.5 };
  const container = document.getElementById('mealPlanContent');

  const mealPlans = {
    high_protein: [
      { name: '🌅 Breakfast', cals: 580, items: 'Scrambled eggs (4 whole) with spinach & feta, 2 slices whole grain toast, 1 medium avocado half, black coffee', protein: 42, carbs: 48, fat: 24 },
      { name: '🥙 Lunch', cals: 680, items: 'Grilled chicken breast (200g) over brown rice (150g cooked), roasted broccoli & bell peppers, tahini drizzle', protein: 52, carbs: 68, fat: 18 },
      { name: '⚡ Pre-Workout', cals: 340, items: 'Greek yogurt (200g) with banana, honey drizzle, 30g oats, handful of almonds', protein: 24, carbs: 46, fat: 8 },
      { name: '🍽️ Dinner', cals: 720, items: 'Pan-seared salmon fillet (200g) with sweet potato mash (200g), steamed asparagus, lemon-herb sauce', protein: 48, carbs: 65, fat: 22 },
      { name: '🥤 Recovery Snack', cals: 360, items: 'Whey protein shake (40g) blended with frozen berries, 1 tbsp peanut butter, oat milk', protein: 36, carbs: 28, fat: 10 }
    ],
    vegetarian: [
      { name: '🌅 Breakfast', cals: 520, items: 'Tofu scramble (200g firm tofu) with turmeric, mushrooms, spinach, whole grain toast with hummus', protein: 34, carbs: 52, fat: 18 },
      { name: '🥙 Lunch', cals: 640, items: 'Chickpea & quinoa bowl (200g) with roasted vegetables, feta cheese, mixed greens, balsamic glaze', protein: 32, carbs: 78, fat: 20 },
      { name: '⚡ Pre-Workout', cals: 320, items: 'Cottage cheese (200g) with mixed berries, granola (40g), drizzle of honey', protein: 28, carbs: 40, fat: 6 },
      { name: '🍽️ Dinner', cals: 680, items: 'Lentil dal (250g) with basmati rice, paneer tikka (100g), cucumber raita, naan bread', protein: 38, carbs: 82, fat: 18 },
      { name: '🥤 Recovery Snack', cals: 340, items: 'Plant protein shake (35g pea protein), banana, almond butter (1 tbsp), soy milk', protein: 32, carbs: 34, fat: 10 }
    ],
    vegan: [
      { name: '🌅 Breakfast', cals: 510, items: 'Overnight oats (80g) with chia seeds, coconut yogurt, mixed berries, hemp seeds, maple syrup', protein: 22, carbs: 68, fat: 16 },
      { name: '🥙 Lunch', cals: 620, items: 'Tempeh stir-fry (200g) with brown rice noodles, bok choy, edamame, ginger-tamari sauce', protein: 38, carbs: 70, fat: 16 },
      { name: '⚡ Pre-Workout', cals: 310, items: 'Banana with almond butter (2 tbsp), handful of trail mix, dates (3)', protein: 12, carbs: 50, fat: 14 },
      { name: '🍽️ Dinner', cals: 690, items: 'Black bean & sweet potato burrito bowl with guacamole, salsa, cilantro-lime rice, nutritional yeast', protein: 30, carbs: 92, fat: 18 },
      { name: '🥤 Recovery Snack', cals: 350, items: 'Soy protein shake (35g), frozen mango, spinach, flaxseed, oat milk', protein: 32, carbs: 38, fat: 8 }
    ],
    pescatarian: [
      { name: '🌅 Breakfast', cals: 550, items: 'Smoked salmon (80g) on whole grain bagel with cream cheese, capers, red onion, dill', protein: 34, carbs: 50, fat: 20 },
      { name: '🥙 Lunch', cals: 650, items: 'Tuna poke bowl with sushi rice (150g), avocado, edamame, cucumber, seaweed, sesame-soy dressing', protein: 44, carbs: 66, fat: 18 },
      { name: '⚡ Pre-Workout', cals: 320, items: 'Greek yogurt (200g) with granola, honey, sliced almonds, banana', protein: 24, carbs: 44, fat: 8 },
      { name: '🍽️ Dinner', cals: 700, items: 'Garlic butter shrimp (250g) with linguine (100g dry), roasted cherry tomatoes, arugula, parmesan', protein: 48, carbs: 68, fat: 20 },
      { name: '🥤 Recovery Snack', cals: 340, items: 'Whey protein (35g) with frozen berries, oat milk, 1 tbsp almond butter', protein: 34, carbs: 30, fat: 10 }
    ],
    keto: [
      { name: '🌅 Breakfast', cals: 580, items: 'Bacon (4 strips) & eggs (3 whole) cooked in butter, avocado half, handful of cherry tomatoes', protein: 38, carbs: 6, fat: 46 },
      { name: '🥙 Lunch', cals: 640, items: 'Bunless burger patties (200g beef) with cheddar, lettuce wrap, mayo, pickles, side caesar salad', protein: 48, carbs: 8, fat: 48 },
      { name: '⚡ Pre-Workout', cals: 280, items: 'Handful of macadamia nuts, string cheese (2), celery with almond butter', protein: 14, carbs: 6, fat: 24 },
      { name: '🍽️ Dinner', cals: 720, items: 'Ribeye steak (250g) with garlic herb butter, roasted cauliflower mash, sautéed green beans in olive oil', protein: 52, carbs: 10, fat: 54 },
      { name: '🥤 Recovery Snack', cals: 320, items: 'Casein protein (30g) mixed with coconut cream, topped with coconut flakes and dark chocolate chips (10g)', protein: 28, carbs: 8, fat: 20 }
    ]
  };

  const diet = p.diet || 'high_protein';
  const meals = mealPlans[diet] || mealPlans.high_protein;

  let html = '';
  meals.forEach(meal => {
    html += `<div class="meal-card">
      <div class="meal-header">
        <span class="meal-name">${meal.name}</span>
        <span class="meal-cals">${meal.cals} kcal</span>
      </div>
      <div class="meal-items">${meal.items}</div>
      <div class="meal-macros">
        <span class="meal-macro macro-protein">P: ${meal.protein}g</span>
        <span class="meal-macro macro-carbs">C: ${meal.carbs}g</span>
        <span class="meal-macro macro-fat">F: ${meal.fat}g</span>
      </div>
    </div>`;
  });

  container.innerHTML = html;
}

// ===== PROGRESS TRACKING =====
function progressStorageKey() {
  return APP_STATE.currentUser ? `aurafit_progress_${APP_STATE.currentUser.id}` : null;
}

function loadProgressLogsForCurrentUser() {
  const key = progressStorageKey();
  if (!key) { APP_STATE.progressLogs = []; return; }
  try {
    const saved = JSON.parse(localStorage.getItem(key) || '[]');
    APP_STATE.progressLogs = Array.isArray(saved) ? saved : [];
  } catch (_) { APP_STATE.progressLogs = []; }
  DB.progress_logs = DB.progress_logs.filter(log => log.user_id !== APP_STATE.currentUser.id).concat(APP_STATE.progressLogs);
}

function persistProgressLogs() {
  const key = progressStorageKey();
  if (!key) return;
  const logs = DB.progress_logs.filter(log => log.user_id === APP_STATE.currentUser.id);
  try {
    localStorage.setItem(key, JSON.stringify(logs));
    APP_STATE.progressLogs = logs;
  } catch (error) {
    alert('Could not save this check-in in browser storage. Try a smaller photo or remove older photo check-ins.');
    throw error;
  }
}

function compressProgressPhoto(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error('Could not read the selected photo.'));
    reader.onload = () => {
      const image = new Image();
      image.onerror = () => reject(new Error('The selected file is not a valid image.'));
      image.onload = () => {
        const maxWidth = 900, maxHeight = 1200;
        const scale = Math.min(1, maxWidth / image.width, maxHeight / image.height);
        const canvas = document.createElement('canvas');
        canvas.width = Math.max(1, Math.round(image.width * scale));
        canvas.height = Math.max(1, Math.round(image.height * scale));
        const context = canvas.getContext('2d');
        context.drawImage(image, 0, 0, canvas.width, canvas.height);
        resolve(canvas.toDataURL('image/jpeg', 0.72));
      };
      image.src = reader.result;
    };
    reader.readAsDataURL(file);
  });
}

async function handleProgressPhotoUpload(input) {
  const file = input.files && input.files[0];
  if (!file) return;
  if (!['image/jpeg', 'image/png', 'image/webp'].includes(file.type)) {
    alert('Please upload a JPG, PNG or WebP image.'); input.value = ''; return;
  }
  if (file.size > 10 * 1024 * 1024) {
    alert('Please choose an image smaller than 10 MB.'); input.value = ''; return;
  }
  try {
    APP_STATE.pendingProgressPhoto = await compressProgressPhoto(file);
    const preview = document.getElementById('progressPhotoPreview');
    const placeholder = document.getElementById('progressPhotoPlaceholder');
    preview.src = APP_STATE.pendingProgressPhoto;
    preview.hidden = false;
    placeholder.hidden = true;
    document.getElementById('removeProgressPhotoBtn').hidden = false;
  } catch (error) {
    alert(error.message || 'Unable to process this photo.');
    input.value = '';
  }
}

function removeProgressPhoto() {
  APP_STATE.pendingProgressPhoto = null;
  const input = document.getElementById('progressPhotoInput');
  const preview = document.getElementById('progressPhotoPreview');
  const placeholder = document.getElementById('progressPhotoPlaceholder');
  const removeButton = document.getElementById('removeProgressPhotoBtn');
  if (input) input.value = '';
  if (preview) { preview.removeAttribute('src'); preview.hidden = true; }
  if (placeholder) placeholder.hidden = false;
  if (removeButton) removeButton.hidden = true;
}

function handleProgressPhotoDragOver(event) {
  event.preventDefault();
  document.getElementById('progressPhotoDropzone').classList.add('drag-over');
}
function handleProgressPhotoDragLeave(event) {
  event.preventDefault();
  document.getElementById('progressPhotoDropzone').classList.remove('drag-over');
}
function handleProgressPhotoDrop(event) {
  event.preventDefault();
  const zone = document.getElementById('progressPhotoDropzone');
  zone.classList.remove('drag-over');
  const file = event.dataTransfer.files && event.dataTransfer.files[0];
  if (!file) return;
  const input = document.getElementById('progressPhotoInput');
  const transfer = new DataTransfer();
  transfer.items.add(file);
  input.files = transfer.files;
  handleProgressPhotoUpload(input);
}

function renderProgressPhotoHistory() {
  const container = document.getElementById('progressPhotoHistory');
  if (!container || !APP_STATE.currentUser) return;
  const photos = DB.progress_logs
    .filter(log => log.user_id === APP_STATE.currentUser.id && log.photo_data_url)
    .sort((a, b) => new Date(a.logged_at) - new Date(b.logged_at));
  if (!photos.length) {
    container.innerHTML = '<p class="empty-state">Your uploaded progress photos will appear here after your first photo check-in.</p>';
    return;
  }
  container.innerHTML = photos.map((log, index) => `
    <article class="progress-photo-entry">
      <img src="${log.photo_data_url}" alt="Progress photo from ${log.logged_at}" loading="lazy">
      <strong>Check-in ${index + 1}</strong>
      <small>${new Date(log.logged_at + 'T00:00:00').toLocaleDateString()}</small>
      <small class="photo-weight">${Number(log.weight_kg).toFixed(1)} kg</small>
    </article>`).join('');
}

function logProgress(e) {
  e.preventDefault();
  if (!APP_STATE.currentUser) { openAuthModal(); return; }
  const entry = {
    id: crypto.randomUUID ? crypto.randomUUID() : 'log-' + Date.now(),
    user_id: APP_STATE.currentUser.id,
    weight_kg: +document.getElementById('progWeight').value,
    waist_cm: +document.getElementById('progWaist').value,
    chest_cm: +document.getElementById('progChest').value,
    arm_cm: +document.getElementById('progArm').value,
    adherence_rpe: document.getElementById('progAdherence').value,
    photo_data_url: APP_STATE.pendingProgressPhoto || null,
    adaptive_action_taken: 'Logged via check-in form',
    logged_at: new Date().toISOString().split('T')[0]
  };
  DB.progress_logs.push(entry);
  try { persistProgressLogs(); }
  catch (_) { DB.progress_logs = DB.progress_logs.filter(log => log.id !== entry.id); return; }
  renderProgressChart();
  renderProgressPhotoHistory();
  e.target.reset();
  removeProgressPhoto();
  const btn = e.target.querySelector('button[type="submit"]');
  const orig = btn.innerHTML;
  btn.innerHTML = '✅ Check-In Saved!';
  setTimeout(() => { btn.innerHTML = orig; }, 2000);
}

// ===== CHECK-IN COLUMN BAR GRAPH (Replaces Progress Line Chart) =====
function renderProgressChart() {
  const svg = document.getElementById('progressChart');
  if (!APP_STATE.currentUser) {
    svg.innerHTML = '<text x="380" y="140" text-anchor="middle" fill="var(--text-muted)" font-size="14">Sign in to view progress</text>';
    return;
  }
  const logs = DB.progress_logs.filter(l => l.user_id === APP_STATE.currentUser.id);
  if (logs.length === 0) {
    svg.innerHTML = '<text x="380" y="140" text-anchor="middle" fill="var(--text-muted)" font-size="14">Log your first check-in above to see your weight bar graph</text>';
    return;
  }

  const padding = { top: 35, right: 70, bottom: 45, left: 55 };
  const chartW = 760 - padding.left - padding.right;
  const chartH = 280 - padding.top - padding.bottom;

  const weights = logs.map(l => l.weight_kg);
  const targetW = 78;
  const minW = Math.floor(Math.min(...weights, targetW) - 3);
  const maxW = Math.ceil(Math.max(...weights, targetW) + 3);

  let html = '';

  // Y-axis grid lines
  const steps = 4;
  for (let i = 0; i <= steps; i++) {
    const y = padding.top + (chartH / steps) * i;
    const val = (maxW - (maxW - minW) * (i / steps)).toFixed(1);
    html += `<line x1="${padding.left}" y1="${y}" x2="${760 - padding.right}" y2="${y}" stroke="var(--border-subtle)" stroke-width="1" stroke-dasharray="4 4" opacity="0.5"/>`;
    html += `<text x="${padding.left - 10}" y="${y + 4}" text-anchor="end" fill="var(--text-muted)" font-size="11" font-family="var(--font-sans)">${val} kg</text>`;
  }

  // Draw bars for each check-in
  const slotW = chartW / logs.length;
  const barW = Math.min(48, slotW * 0.55);

  logs.forEach((log, i) => {
    const centerX = padding.left + slotW * i + slotW / 2;
    const barH = ((log.weight_kg - minW) / (maxW - minW)) * chartH;
    const x = centerX - barW / 2;
    const y = padding.top + chartH - barH;

    // Bar
    html += `<rect x="${x}" y="${y}" width="${barW}" height="${barH}" rx="6" fill="#06b6d4" opacity="0.9"/>`;
    // Weight label on top of bar
    html += `<text x="${centerX}" y="${y - 8}" text-anchor="middle" fill="var(--text-main)" font-size="11" font-weight="700">${log.weight_kg} kg</text>`;
    // Date label on bottom
    html += `<text x="${centerX}" y="${280 - 15}" text-anchor="middle" fill="var(--text-secondary)" font-size="11" font-weight="600">${log.logged_at.substring(5)}</text>`;
  });

  // Target Goal Line
  const targetY = padding.top + chartH * (1 - (targetW - minW) / (maxW - minW));
  html += `<line x1="${padding.left}" y1="${targetY}" x2="${760 - padding.right}" y2="${targetY}" stroke="var(--accent-emerald)" stroke-width="2" stroke-dasharray="6 4"/>`;
  html += `<text x="${760 - padding.right + 6}" y="${targetY + 4}" fill="var(--accent-emerald)" font-size="11" font-weight="700">Goal: ${targetW}kg</text>`;

  svg.innerHTML = html;
}

// ===== ADAPTIVE FEEDBACK =====
function triggerScenario(type) {
  document.querySelectorAll('.scenario-btn').forEach(b => b.classList.remove('active'));
  event.target.classList.add('active');

  const container = document.getElementById('adaptiveFeedback');
  const scenarios = {
    plateau: {
      icon: '📉',
      title: 'Plateau Detected — Adaptive Response Triggered',
      class: 'alert-warn',
      items: [
        { label: 'Caloric Adjustment', action: 'Decrease daily intake by 150 kcal (current TDEE adjusted from 2,680 → 2,530 kcal)' },
        { label: 'Cardio Addition', action: 'Add 10 minutes LISS cardio (brisk walk or cycling) post-workout on training days' },
        { label: 'Exercise Variation', action: 'Swap Barbell Bench Press → Incline DB Press; Leg Press → Front Squat for novel stimulus' },
        { label: 'Reassessment', action: 'Auto-scheduled reassessment in 2 weeks. If plateau persists, initiate refeed protocol.' }
      ]
    },
    fatigue: {
      icon: '😴',
      title: 'High Fatigue / Deload Week Protocol',
      class: 'alert-info',
      items: [
        { label: 'Volume Reduction', action: 'Reduce total weekly sets by 40% across all muscle groups (maintain frequency)' },
        { label: 'Intensity Cap', action: 'Cap all working sets at RPE 6 — no sets to failure this week' },
        { label: 'Protein Boost', action: 'Increase protein to 2.5g/kg for enhanced recovery and muscle protein synthesis' },
        { label: 'Sleep & Recovery', action: 'Prioritize 8+ hours sleep. Add 5-minute post-workout stretching protocol.' }
      ]
    },
    surge: {
      icon: '💪',
      title: 'Hypertrophy Surge — Progressive Overload Microcycle',
      class: 'alert-success',
      items: [
        { label: 'Load Progression', action: 'Advance all compound lifts to next progressive overload step (+2.5 kg per exercise)' },
        { label: 'Volume Increase', action: 'Add 1 additional working set to priority muscle groups (Lateral Delts, Upper Chest, Lats)' },
        { label: 'Tempo Manipulation', action: 'Introduce 4-second eccentric on isolation exercises for enhanced time under tension' },
        { label: 'Nutrition Sync', action: 'Increase daily surplus by 100 kcal to fuel additional training volume' }
      ]
    }
  };

  const s = scenarios[type];
  let html = `<div class="alert-box ${s.class}">
    <div class="alert-title">${s.icon} ${s.title}</div>
    <div style="margin-top:12px;">`;
  s.items.forEach(item => {
    html += `<div style="margin-bottom:10px;">
      <strong style="color:var(--text-main);font-size:0.85rem;">${item.label}:</strong>
      <span style="font-size:0.82rem;color:var(--text-secondary);margin-left:4px;">${item.action}</span>
    </div>`;
  });
  html += '</div></div>';
  container.innerHTML = html;
}

// ===== AUTH MODAL: Click outside to close =====
document.getElementById('authModal').addEventListener('click', function(e) {
  if (e.target === this && APP_STATE.currentUser) closeAuthModal();
});

// ===== KEYBOARD: Escape closes modal =====
document.addEventListener('keydown', function(e) {
  if (e.key === 'Escape' && APP_STATE.currentUser) closeAuthModal();
});

// ===== INITIALIZATION =====
document.addEventListener('DOMContentLoaded', function() {
  initTheme();
  captureAndEmptyDashboards();
  setDashboardAccess(false);
  initAuth();
});
